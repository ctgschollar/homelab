"""Session CRUD operations."""
